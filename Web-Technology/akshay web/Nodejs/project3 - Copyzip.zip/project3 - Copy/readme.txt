npm init -y  -->json file
npm i express mongoose ejs  -->pacakeg lock created

mongod.exe
mono.exe     
//gmail app password to send email through code-->nodejsak
xsnv iqbu cwkh agfg